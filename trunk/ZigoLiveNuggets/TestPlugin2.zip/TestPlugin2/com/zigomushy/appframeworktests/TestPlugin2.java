package com.zigomushy.appframeworktests;


import com.zigolive.liveup.Plugin;

public class TestPlugin2 extends Plugin
{

	public void Test(String s){
		System.out.println("Line 9 (TestPlugin)>" + s);
	}
	
	
}
