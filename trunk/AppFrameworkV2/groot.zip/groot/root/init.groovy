/*@@STAY OUT!!!@@*/

GSystem.env = new Expando();


GSystem.env.pstr = ">"

GSystem.env.home = "home/tim"
GSystem.env.cwd = GSystem.env.home
GSystem.env.path = "/etc/bin"

//import org.millscript.commons.vfs.VFS;
//import org.millscript.commons.vfs.util.ChrootVolume;
//GSystem.root = new ChrootVolume(new VFS().resolveAsFolder(new java.net.URI("file:///G:/groot")));
